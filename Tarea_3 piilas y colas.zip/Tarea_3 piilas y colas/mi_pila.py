from pasajero import Pasajero


class MiPila:
    """Pila (LIFO) hecha a mano sobre un arreglo de tamaño fijo.
    datos -> [fondo, ..., TOPE, None, None]
    TOPE  -> datos[cantidad - 1]  (el último que entró: el único que se ve y el único que sale)
    ⛔ Mismas prohibiciones que MiLista: sin append, pop, insert, remove, index,
       sort, reverse, copy, len(), in, slicing ni comprensiones.
    """

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad
        self.capacidad = capacidad
        self.cantidad = 0

    def apilar(self, pasajero):                      # ✅ resuelto (= añadir de MiLista)
        if self.cantidad == self.capacidad:
            print("  ⚠ La pila está llena")
            return False
        if self.buscar(pasajero.numero) != -1:        # no repetidos (mejora de la guía)
            print(f"  ⚠ Ya existe un pasajero con el número {pasajero.numero}")
            return False
        self.datos[self.cantidad] = pasajero          # el nuevo queda encima: es el TOPE
        self.cantidad = self.cantidad + 1
        return True

    def listar(self):                                 # ✅ EJEMPLO: del TOPE al FONDO
        if self.cantidad == 0:
            print("  (pila vacía)")
            return
        for i in range(self.cantidad - 1, -1, -1):    # cantidad-1, ..., 1, 0  (hacia atrás)
            if i == self.cantidad - 1:
                print(f"  [{i}] {self.datos[i]}  ← TOPE")
            elif i == 0:
                print(f"  [{i}] {self.datos[i]}  ← FONDO")
            else:
                print(f"  [{i}] {self.datos[i]}")

    # ------- ✍ IMPLEMENTA (tabla 3) · recorre SIEMPRE del tope al fondo -------
    def desapilar(self):
        if self.cantidad == 0:
            return None
        tope = self.datos[self.cantidad - 1]
        self.datos[self.cantidad - 1] = None            # no se corre nada
        self.cantidad = self.cantidad - 1
        return tope

    def ver_tope(self):
        if self.cantidad == 0:
            return None
        return self.datos[self.cantidad - 1]

    def buscar(self, numero, mostrar=False):
        """Búsqueda lineal del tope al fondo. Retorna la posición o -1."""
        recorrido = ""
        for i in range(self.cantidad - 1, -1, -1):
            if mostrar:
                if recorrido != "":
                    recorrido = recorrido + " → "
                recorrido = recorrido + self.datos[i].nombre
            if self.datos[i].numero == numero:
                if mostrar:
                    print(f"  (revisó {recorrido})")
                return i
        if mostrar and recorrido != "":
            print(f"  (revisó {recorrido})")
        return -1

    def modificar(self, numero, nuevo_destino, nuevo_asiento):
        pos = self.buscar(numero)                       # reutiliza buscar
        if pos == -1:
            return False
        self.datos[pos].destino = nuevo_destino
        self.datos[pos].asiento = nuevo_asiento
        return True

    def eliminar_por_numero(self, numero):
        """Desapila hacia una pila auxiliar hasta encontrarlo; luego restaura."""
        if self.buscar(numero) == -1:
            return False
        aux = MiPila(self.capacidad)
        while True:
            p = self.desapilar()
            if p.numero == numero:
                break                                    # se descarta
            aux.apilar(p)
        while aux.cantidad > 0:
            self.apilar(aux.desapilar())                 # el orden queda igual
        return True

    def copiar(self):
        nueva = MiPila(self.capacidad)
        for i in range(self.cantidad):                   # del fondo al tope
            nueva.apilar(self.datos[i])
        return nueva

    def longitud(self):
        return self.cantidad

    def esta_vacia(self):
        return self.cantidad == 0

    # ================== EXTRAS QUE PIDE EL INGENIERO ==================
    # "Ascendente" = datos[0] (fondo) el menor ... TOPE el mayor, por N.º de pasajero.

    def esta_ordenada_asc(self):
        """True si fondo→tope va de menor a mayor. Desapila a una auxiliar y restaura."""
        ordenada = True
        aux = MiPila(self.capacidad)
        anterior = None
        while self.cantidad > 0:
            p = self.desapilar()                         # sale del tope hacia el fondo
            if anterior is not None and p.numero > anterior.numero:
                ordenada = False
            anterior = p
            aux.apilar(p)
        while aux.cantidad > 0:
            self.apilar(aux.desapilar())
        return ordenada

    def _ordenar(self, ascendente):
        """Ordenamiento por inserción con una pila auxiliar (solo toca el tope)."""
        aux = MiPila(self.capacidad)
        while self.cantidad > 0:
            tmp = self.desapilar()
            if ascendente:
                while aux.cantidad > 0 and aux.ver_tope().numero < tmp.numero:
                    self.apilar(aux.desapilar())
            else:
                while aux.cantidad > 0 and aux.ver_tope().numero > tmp.numero:
                    self.apilar(aux.desapilar())
            aux.apilar(tmp)
        while aux.cantidad > 0:                          # aux → self invierte el sentido
            self.apilar(aux.desapilar())

    def ordenar_asc(self):
        if self.cantidad == 0:
            return False
        self._ordenar(True)
        return True

    def ordenar_desc(self):
        if self.cantidad == 0:
            return False
        self._ordenar(False)
        return True

    def reversar(self):
        """Con dos pilas auxiliares: self → aux1 → aux2 → self."""
        if self.cantidad == 0:
            return False
        aux1 = MiPila(self.capacidad)
        aux2 = MiPila(self.capacidad)
        while self.cantidad > 0:
            aux1.apilar(self.desapilar())
        while aux1.cantidad > 0:
            aux2.apilar(aux1.desapilar())
        while aux2.cantidad > 0:
            self.apilar(aux2.desapilar())
        return True

    def buscar_binaria(self, numero, mostrar=False):
        """Posición, -1 si no existe, -2 si NO está ordenada ascendente.
        (Lee datos[medio] directo: la búsqueda binaria lo exige.)"""
        if not self.esta_ordenada_asc():
            return -2
        bajo = 0
        alto = self.cantidad - 1
        paso = 1
        while bajo <= alto:
            medio = (bajo + alto) // 2
            if mostrar:
                print(f"  paso {paso}: bajo={bajo} alto={alto} medio={medio} → #{self.datos[medio].numero}")
            paso = paso + 1
            if self.datos[medio].numero == numero:
                return medio
            elif self.datos[medio].numero < numero:
                bajo = medio + 1
            else:
                alto = medio - 1
        return -1

    def insertar_en_posicion(self, pos, pasajero):
        """Inserta de modo que quede en datos[pos] (0 = fondo, cantidad = tope).
        Desapila lo que está encima a una auxiliar, apila el nuevo y restaura."""
        if self.cantidad == self.capacidad:
            print("  ⚠ La pila está llena")
            return False
        if pos < 0 or pos > self.cantidad:
            print(f"  ⚠ Posición inválida (0 a {self.cantidad})")
            return False
        if self.buscar(pasajero.numero) != -1:
            print(f"  ⚠ Ya existe un pasajero con el número {pasajero.numero}")
            return False
        aux = MiPila(self.capacidad)
        while self.cantidad > pos:
            aux.apilar(self.desapilar())
        self.apilar(pasajero)
        while aux.cantidad > 0:
            self.apilar(aux.desapilar())
        return True
