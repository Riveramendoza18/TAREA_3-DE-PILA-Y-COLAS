from pasajero import Pasajero
from mi_pila import MiPila
from mi_cola import MiCola

pila = MiPila(10)
cola = MiCola(10)


# ------------------------- funciones de apoyo ✅ -------------------------
def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("  Debe ser un número entero.")


def leer_entero_rango(mensaje, minimo=None, maximo=None):
    """Pide un entero y repite hasta que sea válido (y esté dentro del rango si se da)."""
    while True:
        try:
            valor = int(input(mensaje))
        except ValueError:
            print("  Debe ser un número entero.")
            continue
        if minimo is not None and valor < minimo:
            print(f"  Debe ser mayor o igual a {minimo}.")
        elif maximo is not None and valor > maximo:
            print(f"  Debe ser menor o igual a {maximo}.")
        else:
            return valor


def leer_texto(mensaje):
    """Texto que no puede quedar vacío."""
    while True:
        texto = input(mensaje).strip()
        if texto != "":
            return texto
        print("  No puede estar vacío.")


def leer_cedula(mensaje):
    """Exactamente 10 dígitos."""
    while True:
        cedula = input(mensaje).strip()
        if cedula.isdigit() and len(cedula) == 10:
            return cedula
        print("  La cédula debe tener 10 dígitos numéricos.")


def leer_fecha(mensaje):
    """Formato AAAA-MM-DD con mes 1-12 y día 1-31."""
    while True:
        fecha = input(mensaje).strip()
        partes = fecha.split("-")
        if (len(partes) == 3 and len(partes[0]) == 4 and len(partes[1]) == 2
                and len(partes[2]) == 2 and fecha.replace("-", "").isdigit()
                and 1 <= int(partes[1]) <= 12 and 1 <= int(partes[2]) <= 31):
            return fecha
        print("  Fecha inválida. Usa el formato AAAA-MM-DD (ej. 2026-11-15).")


def leer_asiento(mensaje):
    """Dos dígitos y una letra, ej. 03C."""
    while True:
        asiento = input(mensaje).strip().upper()
        if (len(asiento) == 3 and asiento[0:2].isdigit() and asiento[2].isalpha()):
            return asiento
        print("  Asiento inválido. Usa el formato 03C (2 dígitos + 1 letra).")


def leer_pasajero():
    numero = leer_entero_rango("  N.º de pasajero: ", 1)
    nombre = leer_texto("  Nombre: ")
    cedula = leer_cedula("  Cédula: ")
    edad = leer_entero_rango("  Edad: ", 0, 120)
    fecha = leer_fecha("  Fecha de vuelo (AAAA-MM-DD): ")
    destino = leer_texto("  Destino: ")
    asiento = leer_asiento("  Asiento: ")
    return Pasajero(numero, nombre, cedula, edad, fecha, destino, asiento)


def datos_prueba():
    """Los 5 pasajeros de prueba en ORDEN DE LLEGADA (Diana llega primero, Elena última)."""
    return [
        Pasajero(1005, "Diana", "0923456789", 22, "2026-11-15", "Quito",  "12A"),
        Pasajero(1002, "Ana",   "0912345678", 28, "2026-11-15", "Lima",   "03C"),
        Pasajero(1009, "Luis",  "0987654321", 35, "2026-11-20", "Bogotá", "18F"),
        Pasajero(1004, "Beto",  "0934567890", 16, "2026-11-20", "Quito",  "07B"),
        Pasajero(1001, "Elena", "0901234567", 41, "2026-11-22", "Lima",   "01A"),
    ]


def mostrar_opciones(titulo, entrar, salir, ver):
    print(f"\n========== {titulo} ==========")
    print(f" 1. {entrar:<12}  2. Listar          3. {salir}")
    print(f" 4. {ver:<12}  5. Buscar          6. Modificar")
    print(" 7. Eliminar por número         8. Copiar")
    print(" 9. Longitud / ¿vacía?")
    print("10. Búsqueda binaria          11. Ordenar ascendente")
    print("12. Ordenar descendente       13. Reversar")
    print("14. Insertar en posición")
    print(" C. Cargar datos de prueba      0. Volver")


# ---------------------- MENÚ 1 · PILA ----------------------
def menu_pila():
    while True:
        mostrar_opciones("MENÚ 1 · PILA (LIFO)", "Apilar", "Desapilar", "Ver tope")
        op = input("Opción: ").strip().upper()

        if op == "1":                                  # ✅ ejemplo resuelto
            pasajero = leer_pasajero()                 # 1. LEER
            if pila.apilar(pasajero):                  # 2. LLAMAR
                print("  ✓ Apilado: ahora es el tope") # 3. MOSTRAR
        elif op == "2":
            pila.listar()
        elif op == "C":
            for p in datos_prueba():
                pila.apilar(p)
            print("  ✓ Datos de prueba apilados")

        # ✍ opciones 3 a 9 (LEER → LLAMAR → MOSTRAR) + extras del ingeniero 10 a 14
        elif op == "3":
            p = pila.desapilar()
            if p is None:
                print("  ⚠ La pila está vacía")
            else:
                print(f"  Salió: {p.nombre}")
                nuevo = pila.ver_tope()
                if nuevo is None:
                    print("  La pila quedó vacía")
                else:
                    print(f"  Nuevo tope: {nuevo.nombre}")
        elif op == "4":
            t = pila.ver_tope()
            if t is None:
                print("  ⚠ La pila está vacía")
            else:
                print(f"  Tope: {t.nombre} ({t.numero})")
        elif op == "5":
            if pila.esta_vacia():
                print("  ⚠ La pila está vacía")
            else:
                numero = leer_entero_rango("  N.º a buscar: ", 1)
                pos = pila.buscar(numero, True)
                if pos == -1:
                    print("  No existe")
                else:
                    print(f"  Encontrado en [{pos}]: {pila.datos[pos].nombre}")
        elif op == "6":
            if pila.esta_vacia():
                print("  ⚠ La pila está vacía")
            else:
                numero = leer_entero_rango("  N.º a modificar: ", 1)
                if pila.buscar(numero) == -1:
                    print("  No existe")
                else:
                    destino = leer_texto("  Nuevo destino: ")
                    asiento = leer_asiento("  Nuevo asiento: ")
                    pila.modificar(numero, destino, asiento)
                    print(f"  ✓ Modificado: {pila.datos[pila.buscar(numero)]}")
        elif op == "7":
            if pila.esta_vacia():
                print("  ⚠ La pila está vacía")
            else:
                numero = leer_entero_rango("  N.º a eliminar: ", 1)
                if pila.eliminar_por_numero(numero):
                    print("  ✓ Eliminado")
                else:
                    print("  No existe")
        elif op == "8":
            if pila.esta_vacia():
                print("  ⚠ La pila está vacía, no hay nada que copiar")
            else:
                copia = pila.copiar()
                print("  ✓ Copia creada:")
                copia.listar()
        elif op == "9":
            print(f"  Longitud: {pila.longitud()} · {'está vacía' if pila.esta_vacia() else 'no está vacía'}")
        elif op == "10":
            if pila.esta_vacia():
                print("  ⚠ La pila está vacía")
            else:
                numero = leer_entero_rango("  N.º a buscar (binaria): ", 1)
                pos = pila.buscar_binaria(numero, True)
                if pos == -2:
                    print("  ⚠ La pila no está ordenada ascendente. Usa primero la opción 11.")
                elif pos == -1:
                    print("  No existe")
                else:
                    print(f"  Encontrado en [{pos}]: {pila.datos[pos].nombre}")
        elif op == "11":
            if pila.ordenar_asc():
                print("  ✓ Ordenada ascendente por N.º de pasajero")
                pila.listar()
            else:
                print("  ⚠ La pila está vacía")
        elif op == "12":
            if pila.ordenar_desc():
                print("  ✓ Ordenada descendente por N.º de pasajero")
                pila.listar()
            else:
                print("  ⚠ La pila está vacía")
        elif op == "13":
            if pila.reversar():
                print("  ✓ Pila reversada")
                pila.listar()
            else:
                print("  ⚠ La pila está vacía")
        elif op == "14":
            if pila.cantidad == pila.capacidad:
                print("  ⚠ La pila está llena")
            else:
                pos = leer_entero_rango(f"  Posición (0 a {pila.cantidad}): ", 0, pila.cantidad)
                pasajero = leer_pasajero()
                if pila.insertar_en_posicion(pos, pasajero):
                    print(f"  ✓ Insertado en [{pos}]")
                    pila.listar()

        elif op == "0":
            break
        else:
            print("  Opción no válida")


# ---------------------- MENÚ 2 · COLA ----------------------
def menu_cola():
    while True:
        mostrar_opciones("MENÚ 2 · COLA (FIFO)", "Encolar", "Desencolar", "Ver frente")
        op = input("Opción: ").strip().upper()

        if op == "1":                                  # ✅ ejemplo resuelto
            pasajero = leer_pasajero()                 # 1. LEER
            if cola.encolar(pasajero):                 # 2. LLAMAR
                print("  ✓ Encolado: está al final")   # 3. MOSTRAR
        elif op == "2":
            cola.listar()
        elif op == "C":
            for p in datos_prueba():
                cola.encolar(p)
            print("  ✓ Datos de prueba encolados")

        # ✍ opciones 3 a 9 (LEER → LLAMAR → MOSTRAR) + extras del ingeniero 10 a 14
        elif op == "3":
            p = cola.desencolar()
            if p is None:
                print("  ⚠ La cola está vacía")
            else:
                print(f"  Salió: {p.nombre}")
                nuevo = cola.ver_frente()
                if nuevo is None:
                    print("  La cola quedó vacía")
                else:
                    print(f"  Nuevo frente: {nuevo.nombre}")
        elif op == "4":
            f = cola.ver_frente()
            if f is None:
                print("  ⚠ La cola está vacía")
            else:
                print(f"  Frente: {f.nombre} ({f.numero})")
        elif op == "5":
            if cola.esta_vacia():
                print("  ⚠ La cola está vacía")
            else:
                numero = leer_entero_rango("  N.º a buscar: ", 1)
                pos = cola.buscar(numero, True)
                if pos == -1:
                    print("  No existe")
                else:
                    print(f"  Encontrado en [{pos}]: {cola.datos[pos].nombre}")
        elif op == "6":
            if cola.esta_vacia():
                print("  ⚠ La cola está vacía")
            else:
                numero = leer_entero_rango("  N.º a modificar: ", 1)
                if cola.buscar(numero) == -1:
                    print("  No existe")
                else:
                    destino = leer_texto("  Nuevo destino: ")
                    asiento = leer_asiento("  Nuevo asiento: ")
                    cola.modificar(numero, destino, asiento)
                    print(f"  ✓ Modificado: {cola.datos[cola.buscar(numero)]}")
        elif op == "7":
            if cola.esta_vacia():
                print("  ⚠ La cola está vacía")
            else:
                numero = leer_entero_rango("  N.º a eliminar: ", 1)
                if cola.eliminar_por_numero(numero):
                    print("  ✓ Eliminado")
                else:
                    print("  No existe")
        elif op == "8":
            if cola.esta_vacia():
                print("  ⚠ La cola está vacía, no hay nada que copiar")
            else:
                copia = cola.copiar()
                print("  ✓ Copia creada:")
                copia.listar()
        elif op == "9":
            print(f"  Longitud: {cola.longitud()} · {'está vacía' if cola.esta_vacia() else 'no está vacía'}")
        elif op == "10":
            if cola.esta_vacia():
                print("  ⚠ La cola está vacía")
            else:
                numero = leer_entero_rango("  N.º a buscar (binaria): ", 1)
                pos = cola.buscar_binaria(numero, True)
                if pos == -2:
                    print("  ⚠ La cola no está ordenada ascendente. Usa primero la opción 11.")
                elif pos == -1:
                    print("  No existe")
                else:
                    print(f"  Encontrado en [{pos}]: {cola.datos[pos].nombre}")
        elif op == "11":
            if cola.ordenar_asc():
                print("  ✓ Ordenada ascendente por N.º de pasajero")
                cola.listar()
            else:
                print("  ⚠ La cola está vacía")
        elif op == "12":
            if cola.ordenar_desc():
                print("  ✓ Ordenada descendente por N.º de pasajero")
                cola.listar()
            else:
                print("  ⚠ La cola está vacía")
        elif op == "13":
            if cola.reversar():
                print("  ✓ Cola reversada")
                cola.listar()
            else:
                print("  ⚠ La cola está vacía")
        elif op == "14":
            if cola.cantidad == cola.capacidad:
                print("  ⚠ La cola está llena")
            else:
                pos = leer_entero_rango(f"  Posición (0 a {cola.cantidad}): ", 0, cola.cantidad)
                pasajero = leer_pasajero()
                if cola.insertar_en_posicion(pos, pasajero):
                    print(f"  ✓ Insertado en [{pos}]")
                    cola.listar()

        elif op == "0":
            break
        else:
            print("  Opción no válida")


# ---------------------- MENÚ PRINCIPAL ✅ ----------------------
def main():
    while True:
        print("\n===== TAREA PILAS Y COLAS · PASAJEROS ✈ =====")
        print("1. Menú 1 · Pila")
        print("2. Menú 2 · Cola")
        print("3. Salir")
        op = input("Opción: ").strip()
        if op == "1":
            menu_pila()
        elif op == "2":
            menu_cola()
        elif op == "3":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción no válida")


if __name__ == "__main__":
    main()
