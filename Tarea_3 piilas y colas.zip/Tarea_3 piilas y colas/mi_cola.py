from pasajero import Pasajero
from mi_pila import MiPila


class MiCola:
    """Cola (FIFO) hecha a mano sobre un arreglo de tamaño fijo.
    datos  -> [FRENTE, ..., FINAL, None, None]
    FRENTE -> datos[0]             (el primero que llegó: el único que sale)
    FINAL  -> datos[cantidad - 1]  (los nuevos se ponen detrás de él)
    ⛔ Mismas prohibiciones que MiLista: sin append, pop, insert, remove, index,
       sort, reverse, copy, len(), in, slicing ni comprensiones.
    """

    def __init__(self, capacidad=10):
        self.datos = [None] * capacidad
        self.capacidad = capacidad
        self.cantidad = 0

    def encolar(self, pasajero):                     # ✅ resuelto (= añadir de MiLista)
        if self.cantidad == self.capacidad:
            print("  ⚠ La cola está llena")
            return False
        if self.buscar(pasajero.numero) != -1:        # no repetidos (mejora de la guía)
            print(f"  ⚠ Ya existe un pasajero con el número {pasajero.numero}")
            return False
        self.datos[self.cantidad] = pasajero          # se pone a la fila por detrás
        self.cantidad = self.cantidad + 1
        return True

    def listar(self):                                 # ✅ EJEMPLO: del FRENTE al FINAL
        if self.cantidad == 0:
            print("  (cola vacía)")
            return
        for i in range(self.cantidad):                # 0, 1, ..., cantidad-1  (hacia adelante)
            if i == 0:
                print(f"  [{i}] {self.datos[i]}  ← FRENTE")
            elif i == self.cantidad - 1:
                print(f"  [{i}] {self.datos[i]}  ← FINAL")
            else:
                print(f"  [{i}] {self.datos[i]}")

    # ------- ✍ IMPLEMENTA (tabla 3) · recorre SIEMPRE del frente al final -------
    def desencolar(self):
        if self.cantidad == 0:
            return None
        frente = self.datos[0]
        for i in range(self.cantidad - 1):               # corre todos a la izquierda
            self.datos[i] = self.datos[i + 1]
        self.datos[self.cantidad - 1] = None
        self.cantidad = self.cantidad - 1
        return frente

    def ver_frente(self):
        if self.cantidad == 0:
            return None
        return self.datos[0]

    def buscar(self, numero, mostrar=False):
        """Búsqueda lineal del frente al final. Retorna la posición o -1."""
        recorrido = ""
        for i in range(self.cantidad):
            if mostrar:
                if recorrido != "":
                    recorrido = recorrido + " → "
                recorrido = recorrido + self.datos[i].nombre
            if self.datos[i].numero == numero:
                if mostrar:
                    print(f"  (revisó {recorrido})")
                return i
        if mostrar and recorrido != "":
            print(f"  (revisó {recorrido})")
        return -1

    def modificar(self, numero, nuevo_destino, nuevo_asiento):
        pos = self.buscar(numero)                       # reutiliza buscar
        if pos == -1:
            return False
        self.datos[pos].destino = nuevo_destino
        self.datos[pos].asiento = nuevo_asiento
        return True

    def eliminar_por_numero(self, numero):
        """Desencola cantidad veces: re-encola a los que no son; la fila da una vuelta."""
        if self.buscar(numero) == -1:
            return False
        n = self.cantidad
        for j in range(n):
            p = self.desencolar()
            if p.numero != numero:
                self.encolar(p)
        return True

    def copiar(self):
        nueva = MiCola(self.capacidad)
        for i in range(self.cantidad):                   # del frente al final
            nueva.encolar(self.datos[i])
        return nueva

    def longitud(self):
        return self.cantidad

    def esta_vacia(self):
        return self.cantidad == 0

    # ================== EXTRAS QUE PIDE EL INGENIERO ==================
    # Se ordena / busca por el N.º de pasajero.

    def esta_ordenada_asc(self):
        """True si la cola está en orden ascendente por número.
        Rota la cola una vuelta completa (desencola y re-encola), así que no la altera."""
        ordenada = True
        anterior = None
        n = self.cantidad
        for j in range(n):
            p = self.desencolar()
            if anterior is not None and anterior.numero > p.numero:
                ordenada = False
            anterior = p
            self.encolar(p)
        return ordenada

    def _ordenar(self, ascendente):
        """Selección usando SOLO desencolar/encolar (respeta FIFO).
        En cada vuelta la cola queda así:  [ sin ordenar | ya ordenados ]."""
        n = self.cantidad
        for k in range(n):
            restantes = n - k
            # Pase 1: una vuelta completa para encontrar el menor (o mayor) de los sin ordenar
            elegido_num = None
            for j in range(n):
                p = self.desencolar()
                if j < restantes:
                    if elegido_num is None:
                        elegido_num = p.numero
                    elif ascendente and p.numero < elegido_num:
                        elegido_num = p.numero
                    elif (not ascendente) and p.numero > elegido_num:
                        elegido_num = p.numero
                self.encolar(p)
            # Pase 2: lo sacamos de los sin ordenar y lo mandamos detrás de los ya ordenados
            elegido = None
            for j in range(n):
                p = self.desencolar()
                if j < restantes and elegido is None and p.numero == elegido_num:
                    elegido = p
                else:
                    self.encolar(p)
            self.encolar(elegido)

    def ordenar_asc(self):
        if self.cantidad == 0:
            return False
        self._ordenar(True)
        return True

    def ordenar_desc(self):
        if self.cantidad == 0:
            return False
        self._ordenar(False)
        return True

    def reversar(self):
        """Desencola todo a una pila auxiliar y luego lo vuelve a encolar."""
        if self.cantidad == 0:
            return False
        aux = MiPila(self.capacidad)
        while self.cantidad > 0:
            aux.apilar(self.desencolar())
        while aux.cantidad > 0:
            self.encolar(aux.desapilar())
        return True

    def buscar_binaria(self, numero, mostrar=False):
        """Retorna la posición, -1 si no existe, o -2 si la cola NO está ordenada asc.
        (Es la única operación que lee datos[medio] directo: la búsqueda binaria lo exige.)"""
        if not self.esta_ordenada_asc():
            return -2
        bajo = 0
        alto = self.cantidad - 1
        paso = 1
        while bajo <= alto:
            medio = (bajo + alto) // 2
            if mostrar:
                print(f"  paso {paso}: bajo={bajo} alto={alto} medio={medio} → #{self.datos[medio].numero}")
            paso = paso + 1
            if self.datos[medio].numero == numero:
                return medio
            elif self.datos[medio].numero < numero:
                bajo = medio + 1
            else:
                alto = medio - 1
        return -1

    def insertar_en_posicion(self, pos, pasajero):
        """Inserta de modo que quede en datos[pos] (0 = frente, cantidad = final).
        Da una vuelta completa a la fila (desencola y re-encola) metiéndolo en su turno."""
        if self.cantidad == self.capacidad:
            print("  ⚠ La cola está llena")
            return False
        if pos < 0 or pos > self.cantidad:
            print(f"  ⚠ Posición inválida (0 a {self.cantidad})")
            return False
        if self.buscar(pasajero.numero) != -1:
            print(f"  ⚠ Ya existe un pasajero con el número {pasajero.numero}")
            return False
        n = self.cantidad
        for j in range(n):
            if j == pos:
                self.encolar(pasajero)
            p = self.desencolar()
            self.encolar(p)
        if pos == n:
            self.encolar(pasajero)
        return True
